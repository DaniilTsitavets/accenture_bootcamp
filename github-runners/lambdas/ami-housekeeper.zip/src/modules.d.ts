declare namespace NodeJS {
  export interface ProcessEnv {
    AMI_CLEANUP_OPTIONS: string;
  }
}
