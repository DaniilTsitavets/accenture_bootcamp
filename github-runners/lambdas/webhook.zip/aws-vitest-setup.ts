import 'aws-sdk-client-mock-jest/vitest';
