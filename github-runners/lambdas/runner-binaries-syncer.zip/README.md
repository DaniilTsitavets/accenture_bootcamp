# Lambda runner binary syncer

For testing the lambda locally check out [this guide](../../../docs/test-lambda-local.md).
